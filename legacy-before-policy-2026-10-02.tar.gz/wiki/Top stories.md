### Top stories

BBC

More

UK military jamming other nations' satellites to defend itself, BBC told

By Jonathan Beale and Vicky Wong

The Guardian

More
- [United Kingdom | AP News](https://apnews.com/hub/united-kingdom)
- [The Telegraph - Telegraph Online, Daily Telegraph, Sunday ...](https://www.telegraph.co.uk)

You are seeing this page because our security systems have detected some unusual activity on this connection. To regain access to The Telegraph website please try the following:

   If you are connected to the internet using a VPN client we recommend disconnecting/disabling it.
   Visit The Telegraph website using a different web browser (e.g. Chrome, Safari, or Firefox).
   Visit The Telegraph website from your mobile device or from a different PC. [...] If you’re still having trouble, please contact our Customer Support Team using the following link and quoting the Akamai Reference Number (ak_ref_id) below.

  
  
 [{"message":"You are not authorized to access this content without a valid TollBit Token. Please follow this URL to find out more.","url":"

